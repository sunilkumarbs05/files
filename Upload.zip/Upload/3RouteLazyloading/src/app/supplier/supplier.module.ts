import { NgModule } from "@angular/core";
import { SupplierComponent } from "../supplier/supplier.component";
import { RouterModule } from "@angular/router";
import { SupplierRouter } from "../router/router.supplier";
import { CommonModule } from "@angular/common";

@NgModule({
  declarations: [
    SupplierComponent
  ],
  imports: [
    RouterModule.forChild(SupplierRouter),
    RouterModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [SupplierComponent]
})
export class SupplierModule {

}