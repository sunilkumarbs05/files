export class Customer {
  code: string = '';
  name: string = '';
  number: number = 0;
}
