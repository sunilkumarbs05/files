import { NgModule } from "@angular/core";
import { CustomerComponent } from "./customer.component";
import { RouterModule } from "@angular/router";
import { CustomerRouter } from "../router/router.customer";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";


@NgModule({
  declarations: [
    CustomerComponent
  ],
  imports: [
    RouterModule.forChild(CustomerRouter),
    FormsModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [CustomerComponent]
})
export class CustomerModule { }
