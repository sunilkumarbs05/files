import { HomeComponent } from "../home/home.component";

export const HomeRouter = [
  { path: 'Home', component: HomeComponent },
];