
import { SupplierComponent } from "../supplier/supplier.component";

export const SupplierRouter = [
  { path: 'Supplier', component: SupplierComponent },
];