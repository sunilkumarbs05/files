import { CustomerComponent } from "../customer/customer.component";

export const CustomerRouter = [
  { path: 'Customer', component: CustomerComponent },
];