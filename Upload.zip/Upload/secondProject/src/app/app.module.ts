import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { SupplierComponent } from './supplier/supplier.component';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { MainRoutes } from './routing/routing.module';

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    SupplierComponent,
    HomeComponent
    
  ],
  imports: [
    RouterModule.forRoot(MainRoutes),
    BrowserModule, 
    FormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
